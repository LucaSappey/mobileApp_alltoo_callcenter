package com.example.best_flutter_ui_templates

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
